import React from "react";
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import CustomerHome from "../../screens/customer/CustomerHome";
import ViewOrders from "../../screens/customer/ViewOrders";
import OrderView from "../../components/OrderView";
const CustomerApp = () => {
    const Stack = createNativeStackNavigator();

    return (
        <NavigationContainer>
            <Stack.Navigator screenOptions={{headerShown: false}} initialRouteName="Home">
                <Stack.Screen name="Home" component={CustomerHome} />
                <Stack.Screen name="Orders" component={ViewOrders} />
                <Stack.Screen name="OrderView" component={OrderView} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}

export default CustomerApp;