import React from "react";
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import CouriorHome from "../../screens/courior/CouriorHome";
import ViewOrders from "../../screens/courior/ViewOrders";
import OrderView from "../../components/OrderView";
import * as TaskManager from 'expo-task-manager';

const CouriorApp = () => {
    const Stack = createNativeStackNavigator();
    TaskManager.defineTask('START_LIVE_LOCATION', ({ data: {locations}, error}) => {
        if (error) {
            console.log('err', error)
            return;
        }

        console.log('Received new locations', locations);
    })
    return (
        <NavigationContainer>
            <Stack.Navigator screenOptions={{headerShown: false}} initialRouteName="Home">
                <Stack.Screen name="Home" component={CouriorHome} />
                <Stack.Screen name="Orders" component={ViewOrders} />
                <Stack.Screen name="OrderView" component={OrderView} />
            </Stack.Navigator>
        </NavigationContainer>
    );
};

export default CouriorApp;