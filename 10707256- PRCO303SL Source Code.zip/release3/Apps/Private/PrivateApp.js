import SnackbarComponent from "expo-snackbar";
import React, { createContext, useEffect, useState } from "react";
import { View, Text } from "react-native";
import LoadingScreen from "../../components/LoadingScreen";
import userService from "../../services/userService";
import AdminApp from "./AdminApp";
import CouriorApp from "./CouriorApp";
import CustomerApp from "./CustomerApp";
import UserContext from "../../components/UserContext";

const PrivateApp = ({ user: firebaseUser }) => {
    const [user, setUser] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        async function fetchUser() {
            try {
                const user = await userService.getUser(firebaseUser.uid)
            if (user) setUser(user);
        
            } catch(err) {
                setError(err.message);
            }
        }

        fetchUser();
    }, [firebaseUser]);

    if (!user) {
        return (
            <LoadingScreen />
        );
    }

   return (
    <UserContext.Provider value={{...user}} >
        {user.type === "customer" && <CustomerApp />}
        {user.type === "admin" && <AdminApp/>}
        {user.type === "courior" && <CouriorApp/>}
    </UserContext.Provider>
   );
    
};

export default PrivateApp;