import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AdminHome from '../../screens/admin/AdminHome';
import ViewRiders from '../../screens/admin/ViewRiders';
import ViewCustomers from '../../screens/admin/ViewCustomers';
import ViewOrders from '../../screens/admin/ViewOrders';
import AddOrder from '../../screens/admin/AddOrder';
import OrderView from '../../components/OrderView';

const AdminApp = () => {
    const Stack = createNativeStackNavigator();

    return (
        <NavigationContainer>
            <Stack.Navigator screenOptions={{headerShown: false}} initialRouteName="Home">
                <Stack.Screen name="Home" component={AdminHome} />
                <Stack.Screen name="Riders" component={ViewRiders} />
                <Stack.Screen name="Customers" component={ViewCustomers} />
                <Stack.Screen name="Orders" component={ViewOrders} />
                <Stack.Screen name="AddOrder" component={AddOrder} />
                <Stack.Screen name="OrderView" component={OrderView} />
            </Stack.Navigator>
        </NavigationContainer>
    );
};

export default AdminApp;