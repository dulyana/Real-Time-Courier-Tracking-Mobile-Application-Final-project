import * as firebaseAuth from 'firebase/auth';
import * as firestore from 'firebase/firestore';
import { doc } from 'firebase/firestore';

const createUser = async ({ category, name, phoneNo, email, password }) => {
    try {
        const auth = firebaseAuth.getAuth();
        const { user } = await firebaseAuth.createUserWithEmailAndPassword(auth, email, password);
        console.log('user id',user.uid)
        await firestore.setDoc(firestore.doc(firestore.getFirestore(), "user", user.uid), {
            uid: user.uid,
            name,
            phoneNo,
            email,
            status: 'active',
            type: category
        });
    } catch(err) {
        throw new Error('Registration failed! Please try again.')
    }
};

const login = async ({ email, password }) => {
    try {
        const auth = firebaseAuth.getAuth();
        const user = await firebaseAuth.signInWithEmailAndPassword(auth, email, password);
    } catch(err) {
        throw new Error('Login failed, Please try again!');
    }
};

const logout = async () => {
    try {
        const auth = firebaseAuth.getAuth();
        await firebaseAuth.signOut(auth);
    } catch(err) {
        throw new Error('Logout failed. Please try again!');
    }
}

const getUser = async (uid) => {
    try {
        const userSnapshot = await firestore.getDoc(firestore.doc(firestore.getFirestore(), "user", uid));

        if (userSnapshot.exists()) {
            return userSnapshot.data();
        } else {
            throw new Error('User not found');
        }
    } catch(err) {
        throw new Error('Get user failed');
    }
}

const getUsers = async (type) => {
    try {
        const userQuery = firestore.query(
            firestore.collection(
                firestore.getFirestore(), 
                "user"), 
                firestore.where("type", "==", type));

        const querySnapshot = await firestore.getDocs(userQuery);

        return querySnapshot.docs.map((doc) => {
            return doc.data();
        })
    } catch(err) {
        console.log(err)
        throw new Error('Fetch users failed');
    }
}

export default {
    createUser,
    logout,
    login,
    getUser,
    getUsers
}