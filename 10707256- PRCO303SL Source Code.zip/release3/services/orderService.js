import * as firestore from 'firebase/firestore';
import { ORDER_STATUS } from '../constants/constants';
import { generateUUID } from '../utils/uuid';
import * as database from 'firebase/database';

const getOrderStats = async () => {
    try {
        const db = firestore.getFirestore();
        const statSnapshop = await firestore.getDoc(firestore.doc(db, "stat", "order"));

        if (statSnapshop.exists()) {
            return statSnapshop.data();
        } else {
            throw new Error('Error fetching order stats');
        }
    } catch (err) {
        throw new Error('Error fetching order stats');
    }
};


const getOrders = async () => {
    try {
        const orderQuery = firestore.query(
            firestore.collection(
                firestore.getFirestore(), 
                "order"), 
                firestore.orderBy("createdAt", "desc"));

        const querySnapshot = await firestore.getDocs(orderQuery);

        return querySnapshot.docs.map((doc) => {
            return doc.data();
        })
    } catch(err) {
        console.log(err)
        throw new Error('Error fetching orders');
    }
};

const getOrder = async (orderId) => {
    try {
        const orderSnapshot = await firestore.getDoc(firestore.doc(firestore.getFirestore(), "order", orderId));

        if (orderSnapshot.exists()) {
            return orderSnapshot.data();
        } else {
            throw new Error('Order not found');
        }
    } catch(err) {
        throw new Error('Get order failed');
    }
};

const getOrdersByCourior = async (couriorId, status) => {
    try {
        let orderQuery;
        if (status) {
            orderQuery = firestore.query(
                firestore.collection(
                    firestore.getFirestore(), 
                    "order"), 
                    firestore.where("rider", "==", couriorId), 
                    firestore.where("status", "==", status), 
                    firestore.orderBy("createdAt", "desc"));
        } else {
            orderQuery = firestore.query(
                firestore.collection(
                    firestore.getFirestore(), 
                    "order"), 
                    firestore.where("rider", "==", couriorId),
                    firestore.orderBy("createdAt", "desc"));
        }

        const querySnapshot = await firestore.getDocs(orderQuery);

        return querySnapshot.docs.map((doc) => {
            return doc.data();
        })
    } catch(err) {
        console.log(err)
        throw new Error('Fetch orders failed');
    }
};

const getOrdersByCustomer = async (customerId, status) => {
    try {
        let orderQuery;
        if (status) {
            orderQuery = firestore.query(
                firestore.collection(
                    firestore.getFirestore(), 
                    "order"), 
                    firestore.where("receiver", "==", customerId), 
                    firestore.where("status", "==", status), 
                    firestore.orderBy("createdAt", "desc"));
        } else {
            orderQuery = firestore.query(
                firestore.collection(
                    firestore.getFirestore(), 
                    "order"), 
                    firestore.where("receiver", "==", customerId),
                    firestore.orderBy("createdAt", "desc"));
        }
        

        const querySnapshot = await firestore.getDocs(orderQuery);

        return querySnapshot.docs.map((doc) => {
            return doc.data();
        })
    } catch(err) {
        console.log(err)
        throw new Error('Fetch orders failed');
    }
};

const updateOrderStats = async (stats) => {
    try {
        await firestore.setDoc(firestore.doc(firestore.getFirestore(), "stat", "order"), {
           ...stats
        });
    } catch (err) {

    }
}

const addOrder = async ({itemName, itemDescription, deliveryDate, deliveryDestination, rider, receiver, address, paymentMethod}) => {
    try {
        const orderId = generateUUID();
        await firestore.setDoc(firestore.doc(firestore.getFirestore(), "order", orderId), {
            orderId,
            itemName,
            itemDescription,
            deliveryDate,
            deliveryDestination,
            rider,
            receiver,
            address,
            paymentMethod,
            status: ORDER_STATUS.PENDING,
            createdAt: new Date()
        });

        const stats = await getOrderStats();
        await updateOrderStats({
            ...stats,
            pending: stats.pending + 1
        });
    } catch(err) {
        throw new Error('Add order failed, Please try again!')
    }
}

const startOrder = async (orderId, userId) => {
    try {
        const existingOngoingOrders = await getOrdersByCourior(userId, ORDER_STATUS.ONGOING);

        if (existingOngoingOrders.length > 0) {
            throw new Error('You have ongoing order already. Please complete it!');
        }

        await firestore.updateDoc(firestore.doc(firestore.getFirestore(), "order", orderId), {
            status: ORDER_STATUS.ONGOING
        });

        await database.set(database.ref(database.getDatabase(), 'orders/'+orderId), {
            status: 'ongoing'
        });

        const stats= await getOrderStats();
        await updateOrderStats({
            ...stats,
            pending: parseInt(stats.pending) - 1,
            ongoing: parseInt(stats.ongoing) + 1
        });
    } catch (err) {
        throw new Error('Start order failed, Please try again!')
    }
};

const completeOrder = async (orderId) => {
    try {
        await firestore.updateDoc(firestore.doc(firestore.getFirestore(), "order", orderId), {
            status: ORDER_STATUS.COMPLETED
        });

        await database.set(database.ref(database.getDatabase(), 'orders/'+orderId), {
            status: 'completed'
        });

        const stats= await getOrderStats();
        await updateOrderStats({
            ...stats,
            ongoing: parseInt(stats.ongoing) - 1,
            completed: parseInt(stats.completed) + 1
        });
    } catch(err) {
        throw new Error('Complete order failed, Please try again!')
    }
}

const updateCurrentLocation = async (orderId, location) => {
    try {
        await database.set(database.ref(database.getDatabase(), 'orders/'+orderId), {
            ...location
        });
    } catch (err) {
        console.log(err)
    }
}

const listenLocationChanges = async (orderId, callback) => {
    try {
        database.onValue(database.ref(database.getDatabase(), 'orders/'+orderId), (snapshot) => {
            const data = snapshot.val();    
            callback(data);
        })
    } catch(err) {
        console.log(err);
    }
}

export default {
    getOrderStats,
    getOrders,
    addOrder,
    getOrdersByCourior,
    getOrdersByCustomer,
    startOrder,
    completeOrder,
    updateCurrentLocation,
    listenLocationChanges,
    getOrder
};