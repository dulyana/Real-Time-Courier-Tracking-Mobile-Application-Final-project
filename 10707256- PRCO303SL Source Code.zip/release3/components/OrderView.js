import React, { useContext, useEffect, useState } from "react";
import { PROVIDER_GOOGLE } from 'expo';
import { ScrollView, Text, TextInput, View, StyleSheet, Image } from "react-native";
import MapView, { Marker } from "react-native-maps";
import userService from "../services/userService";
import CustomButton from "./CustomButton";
import CustomContainer from "./CustomContainer";
import CustomDatePicker from "./CustomDatePicker";
import CustomDropdown from "./CustomDropdown";
import styles from "./styles";
import getDirections from "react-native-google-maps-directions";
import call from 'react-native-phone-call'
import OrderActions from "./OrderAction";
import UserContext from "./UserContext";
import { ORDER_STATUS, USER_TYPE } from "../constants/constants";
import orderService from "../services/orderService";
import packageImage from "../assets/images/package.png";
import CustomActivityIndicator from "./CustomActivityIndicator";
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions';

const OrderView = ({ route }) => {
    const [order, setOrder] = useState();
    const [customer, setCustomer] = useState();
    const [rider, setRider] = useState();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState();
    const [ridersLocation, setRidersLocation] = useState();
    const [locationSharing, setLocationSharing] = useState(false);
    const [locationReceiving, setLocationReceiving] = useState(false);
    const [subscription, setSubscription] = useState();

    const user = useContext(UserContext);

    const fetchOrder = async (orderId) => {
        setLoading(true);
        orderService.getOrder(orderId)
            .then((data) => setOrder(data))
            .catch((err) => setError(err.message))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        return () => {
            if (subscription) {
                console.log('subscription found');
                subscription.remove();
            }else {
                console.log('subscription not found')
            }
        }
    }, [subscription])

    useEffect(() => {
        fetchOrder(route.params.orderId)
    }, [route.params.orderId]);

    const startLiveLocation = async () => {
        const { status } = await Permissions.askAsync(Permissions.LOCATION_FOREGROUND);

        if (!subscription && status === 'granted') {
            const location = await Location.watchPositionAsync({
                timeInterval: 2000,
                accuracy: Location.Accuracy.Highest,
                distanceInterval: 0
            }, (newLocation) => {
                console.log('sending location')
                orderService.updateCurrentLocation(order.orderId, newLocation);
            }).catch(err => console.log(err));
            setSubscription(location);
            setLocationSharing(true);
        }
    }

    const receiveLiveLocation = async () => {
        orderService.listenLocationChanges(order.orderId, (location) => {
            if (location && location.coords) {
                setRidersLocation({...location.coords});
            }else if(location && location.status === ORDER_STATUS.COMPLETED) {
                console.log('completed')
                fetchOrder();
            }
        }).then(() => setLocationReceiving(true)).catch(err => console.log(err));
    }

    const handleStartDelivery = async () => {
        orderService.startOrder(order.orderId, user.uid)
            .then(() => fetchOrder(order.orderId))
            .catch(() => { console.log(err)});
    };

    const handleCompleteDelivery = async (scannedOrderId) => {
        if (scannedOrderId === order.orderId) {
            orderService.completeOrder(order.orderId)
            .then(() => fetchOrder(order.orderId))
            .catch((err) => console.log(err));
        }
    }

    useEffect(() => {
        setLocationReceiving(false);
        setLocationSharing(false);

        if (subscription && order.status !== ORDER_STATUS.ONGOING) {
            console.log('removing')
            subscription.remove();
            setSubscription(false);
        }

        if (order) {
            setLoading(true);
            if (user.type !== USER_TYPE.CUSTOMER) {
                userService.getUser(order.receiver)
                .then((data) => setCustomer(data))
                .catch()
                .finally(() => setLoading(false));
            }

            if (user.type !== USER_TYPE.COURIOR) {
                userService.getUser(order.rider)
                .then((data) => setRider(data))
                .catch()
                .finally(() => setLoading(false))
            } 

            // listen to location changes
            if (user.type !== USER_TYPE.COURIOR && order.status === ORDER_STATUS.ONGOING) {
                receiveLiveLocation();
            }

            // start sending location data
            if (user.type === USER_TYPE.COURIOR && order.status === ORDER_STATUS.ONGOING) {
                startLiveLocation();
            }
        }
    }, [order]);

    const handleGetDirections = () => {
        const data = {
            destination: {
                ...order?.deliveryDestination
            },
            params: [
                {
                    key: "travelmode",
                    value: "driving"  // may be "walking", "bicycling" or "transit" as well
                },
                {
                    key: "dir_action",
                    value: "navigate" // this instantly initializes navigation using the given travel mode
                }
            ]
        }
        getDirections(data)
            .catch();
    }

    const handleOnCall = (phoneNo) => {
        call({
            number: phoneNo,
            promt: false
        }).catch();
    }


    const UserSection = () => {
        switch (user.type) {
            case USER_TYPE.ADMIN:
                return (
                    <View>
                        <Text style={{ marginTop: 15 }}>Receiver</Text>
                        <TextInput
                            style={styles.input}
                            editable={false}
                            
                            value={customer?.name}
                        />
                        <CustomButton title={"Call customer"} 
                            disabled={loading}
                            onPress={() => handleOnCall(customer?.phoneNo)}
                            style={{marginTop: 10, width: 60, backgroundColor: 'green'}}/>
                            <Text style={{ marginTop: 15 }}>Rider</Text>
                        <TextInput
                            style={styles.input}
                            editable={false}
                            
                            value={rider?.name}
                        />
                        <CustomButton title={"Call rider"} 
                            disabled={loading}
                            onPress={() => handleOnCall(rider?.phoneNo)}
                            style={{marginTop: 10, width: 60, backgroundColor: 'green'}}/>
                    </View>
                )

            case USER_TYPE.COURIOR:
                return (
                    <View>
                        <Text style={{ marginTop: 15 }}>Receiver</Text>
                        <TextInput
                            style={styles.input}
                            editable={false}
                            
                            value={customer?.name}
                        />
                        <CustomButton title={"Call customer"} 
                            disabled={loading}
                            onPress={() => handleOnCall(customer?.phoneNo)}
                            style={{marginTop: 10, width: 60, backgroundColor: 'green'}}/>
                    </View>
                )

            case USER_TYPE.CUSTOMER:
                return (
                    <View>
                        <Text style={{ marginTop: 15 }}>Rider</Text>
                        <TextInput
                            style={styles.input}
                            editable={false}
                            
                            value={rider?.name || 'test'}
                        />
                        <CustomButton title={"Call rider"} 
                            disabled={loading}
                            onPress={() => handleOnCall(rider?.phoneNo)}
                            style={{marginTop: 10, width: 60, backgroundColor: 'green'}}/>
                    </View>
                )
        }

        return null;
    }


    return (
        <CustomContainer title={"Order"} >
            {loading && <CustomActivityIndicator />}
            {!loading &&
                <ScrollView style={{ height: "90%" }}>
                <Text style={{ marginTop: 10 }}>Item Name</Text>
                <TextInput
                    style={styles.input}
                    editable={false}
                    value={order?.itemName}
                />
                <Text style={{ marginTop: 15 }}>Item Description</Text>
                <TextInput
                    style={styles.input}
                    editable={false}
                    value={order?.itemDescription}
                />
                
                <UserSection />
                <Text style={{ marginTop: 15 }}>Payment Method</Text>
                <TextInput
                    style={styles.input}
                    editable={false}
                    value={order?.paymentMethod}
                />
                <Text style={{ marginTop: 15 }}>Delivery Date</Text>
                <CustomDatePicker
                    date={order?.deliveryDate?.toDate() || new Date()}
                    
                    style={[{ marginTop: 5 }]}
                />
                <Text style={{ marginTop: 15 }}>Address</Text>
                <TextInput
                    style={styles.input}
                    editable={false}
                    value={order?.address}
                />
                <Text style={{ marginTop: 25 }}>Delivery Destination</Text>
                { locationReceiving &&  <CustomButton title={"Your delivery is on its way"} 
                            disabled={true}
                            onPress={() => {}}
                            style={{marginTop: 10, backgroundColor: 'green'}}/>}
                { locationSharing &&  <CustomButton title={"Live location sharing is on!"} 
                            disabled={true}
                            onPress={() => {}}
                            style={{marginTop: 10, backgroundColor: 'red'}}/>}
                <View style={customStyles.map}>
                    <MapView
                        provider={PROVIDER_GOOGLE}
                        style={[{ height: '100%', width: '100%' }]}
                        initialRegion={order?.deliveryDestination}
                        // showsUserLocation={true}
                        showsMyLocationButton={true}
                    // initialRegion={deliveryDestination} 
                    >
                        {order && order.deliveryDestination && <Marker coordinate={order?.deliveryDestination} />}
                        {order && order.status === ORDER_STATUS.ONGOING && ridersLocation && <Marker 
                        coordinate={{
                            longitude: ridersLocation.longitude,
                            latitude: ridersLocation.latitude,
                            latitudeDelta: 0.0036757928905561954,
                            longitudeDelta: 0.004520528018474579

                        }}>
                            <Image source={packageImage} style={{height: 40, width: 40, resizeMode: 'contain'}}/>
                            </Marker>}
                    </MapView>

                </View>
                {user.type === USER_TYPE.COURIOR && order.status !== ORDER_STATUS.COMPLETED &&
                    <CustomButton 
                    disabled={loading} 
                    title="Get Directions" 
                    onPress={() => handleGetDirections()} 
                    style={{ marginTop: 0, width: '60%'}}/>
                }
                <View style={{height: 50}} />
                {order && <OrderActions 
                    order={order}
                    handleCompleteDelivery={handleCompleteDelivery}
                    handleStartDelivery={handleStartDelivery}
                    loading={loading} />}
            </ScrollView>
            }
        </CustomContainer>
    )
};

const customStyles = StyleSheet.create({
    map: {
        marginTop: 10,
        marginBottom: 10,
        height: 300,
        width: '100%'
    },
    region: {
        color: '#fff',
        lineHeight: 20,
        margin: 20
    }
})

export default OrderView;