import React, { useContext, useEffect, useState } from "react";
import { ActivityIndicator, Text, View } from "react-native";
import { ORDER_STATUS, USER_TYPE } from "../constants/constants";
import orderService from "../services/orderService";
import styles from "./styles";
import UserContext from "./UserContext";

const CustomDashboard = ({ navigation }) => {
    const user = useContext(UserContext);
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({ pending: 0, ongoing: 0, completed: 0});

    const refreshData = async () => {
        let orders = [];

        if (user.type === USER_TYPE.CUSTOMER) {
            orders = await orderService.getOrdersByCustomer(user.uid);
        }else if (user.type === USER_TYPE.COURIOR) {
            orders = await orderService.getOrdersByCourior(user.uid);
        }else if (user.type === USER_TYPE.ADMIN) {
            orders = await orderService.getOrders();
        }
        const pending = orders.filter((order) => order.status === ORDER_STATUS.PENDING);
        const ongoing = orders.filter((order) => order.status === ORDER_STATUS.ONGOING);
        const completed = orders.filter((order) => order.status === ORDER_STATUS.COMPLETED);
        setStats({
          pending: pending.length,
          ongoing: ongoing.length,
          completed: completed.length
        })

    };

    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', () => {
          if (navigation.isFocused()) {
            setLoading(true);
            refreshData()
              .catch(() => {}).
              finally(() => setLoading(false));
          }
        });
        return unsubscribe;
    }, [navigation]);


    return (
        <View style = {{ flexDirection: "row", justifyContent: "space-around", marginBottom: "auto"}}>
        <View style={[ styles.dashboardItem, { backgroundColor: '#F96141'} ]}>
          {!loading &&
            <Text style={ styles.dashboardItemCount }>
              {stats.pending > 99 ? '99+': stats.pending}
            </Text>
          }
          {loading &&
            <ActivityIndicator color="#fff" size="large"/>
          }
          <Text style={ styles.dashboardItemText }>Pending Orders</Text>
        </View>

        <View style={[ styles.dashboardItem, { backgroundColor: '#9FB6BE'} ]}>
          {!loading &&
            <Text style={ styles.dashboardItemCount }>
              {stats.ongoing > 99 ? '99+': stats.ongoing}
            </Text>
          }
          {loading &&
            <ActivityIndicator color="#fff" size="large"/>
          }
          <Text style={ styles.dashboardItemText }>Ongoing Orders</Text>
        </View>

        <View style={[ styles.dashboardItem, { backgroundColor: '#887A21'} ]}> 
          {!loading &&
           <Text style={ styles.dashboardItemCount }>
            {stats.completed > 99 ? '99+': stats.completed}
          </Text>
          }
          {loading &&
            <ActivityIndicator color="#fff" size="large"/>
          }
          <Text style={ styles.dashboardItemText }>Completed Orders</Text>
        </View>
      </View>
    )
};

export default CustomDashboard;