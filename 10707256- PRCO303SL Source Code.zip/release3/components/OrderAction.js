import React, { useContext, useEffect, useState } from "react";
import UserContext from "./UserContext";
import { ORDER_STATUS, USER_TYPE } from "../constants/constants";
import orderService from "../services/orderService";
import CustomButton from "./CustomButton";
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions';
import { Dimensions, Modal, View, Text, StyleSheet } from "react-native";
import { BarCodeScanner } from "expo-barcode-scanner";
import QRCode from "react-native-qrcode-svg";

const OrderActions = ({ order, handleCompleteDelivery, handleStartDelivery, loading }) => {
    const user = useContext(UserContext);
    const [qrModalVisible, setQrModalVisible] = useState(false);
    const [scanned, setScanned] = useState(false);

    useEffect(() => {
        const getBarCodeScannerPermissions = async () => {
            const { status } = await BarCodeScanner.requestPermissionsAsync();
          };
      
          getBarCodeScannerPermissions();
    }, []);

    const handleOnStartDelivery = async () => {
        handleStartDelivery();
    };

    const handleOnCompleteDelivery = async (scannedId) => {
       handleCompleteDelivery(scannedId);  
    };

    if (user.type === USER_TYPE.COURIOR) {
        switch (order.status) {
            case ORDER_STATUS.PENDING: {
                return (
                    <CustomButton title="Start Delivery" onPress={() => handleOnStartDelivery()} />
                );
            }
            case ORDER_STATUS.ONGOING: {
                return (
                    <View>
                        <CustomButton 
                            title="Complete Delivery" 
                            onPress={() => setQrModalVisible(true)} 
                            disabled={loading}
                            />
                        <Modal
                            animationType="slide"
                            style={{
                                height: 100,
                                width: 100
                            }}
                            transparent={true}
                            visible={qrModalVisible}
                            onRequestClose={() => {
                                setQrModalVisible(false);
                            }}
                        >
                            <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}> 
                                <View style={{
                                    height: Dimensions.get("window").height * 0.5,
                                    width: Dimensions.get("window").width * 0.8,
                                    minHeight: 400,
                                    backgroundColor: 'white',
                                    justifyContent: "center", alignItems: "center",
                                    borderRadius: 5,
                                    elevation: 10
                                }}>
                                    <BarCodeScanner 
                                        barCodeTypes={BarCodeScanner.Constants.BarCodeType.qr}
                                        style={{
                                            width: 300,
                                            height: 300
                                        }}
                                        onBarCodeScanned={scanned? undefined: (val) => {
                                            setScanned(true);
                                            handleOnCompleteDelivery(val.data);
                                        }}
                                        />
                                    <Text style={{ marginTop: 20}}>Scan customer's QR code, in order to complete the delivery</Text>
                                </View>
                            </View>
                        </Modal>
                    </View>
                );
            }
        }
    }

    if (user.type === USER_TYPE.CUSTOMER) {
        switch (order.status) {
            case ORDER_STATUS.ONGOING: {
                return (
                    <View>
                        <CustomButton title="Show QR" onPress={() => setQrModalVisible(true)} />
                        <Modal
                            animationType="slide"
                            style={{
                                height: 100,
                                width: 100
                            }}
                            transparent={true}
                            visible={qrModalVisible}
                            onRequestClose={() => {
                                setQrModalVisible(false);
                            }}
                        >
                            <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}> 
                                <View style={{
                                    height: Dimensions.get("window").height * 0.5,
                                    width: Dimensions.get("window").width * 0.8,
                                    minHeight: 400,
                                    backgroundColor: 'white',
                                    justifyContent: "center", alignItems: "center",
                                    borderRadius: 5,
                                    elevation: 10
                                }}>
                                    <QRCode value={order.orderId} size={300}/>
                                    <Text style={{ marginTop: 20}}>Rider should scan this QR code, in order to complete the delivery</Text>
                                </View>
                            </View>
                        </Modal>
                    </View>

                );
            }
        }
    }

    return null;
};

export default OrderActions;