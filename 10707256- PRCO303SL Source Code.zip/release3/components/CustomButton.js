import React from "react";
import { TouchableOpacity, Text, StyleSheet } from "react-native";

const CustomButton = (props) => {
  const { title, onPress, style = {}, textStyle = {}, disabled } = props;

  return (
    <TouchableOpacity 
      style={[ customStyles.button, style ]} 
      onPress={onPress} 
      disabled={disabled}
    >
        <Text style={[ customStyles.buttonText, textStyle ]}>{title}</Text>
    </TouchableOpacity>
  );
};

export default CustomButton;

const customStyles = StyleSheet.create({
  button: {
    backgroundColor: "#FC6140",
    paddingHorizontal: 40,
    minHeight: 40,
    minWidth: 180,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 2,
    color: "white",
    shadowColor: "#000",
    shadowOffset: {
      width: 3,
      height: 3
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5
  },
  buttonText: {
    color: "white",
  }
})