import React from "react";
import { Image, Text, View, Dimensions, ActivityIndicator } from "react-native";
import image from "../assets/images/loginImage.jpg";

const LoadingScreen = () => {

    return (
        <View style={{ 
            display: 'flex', 
            flexDirection: 'column', 
            justifyContent: 'center', 
            alignItems: 'center',
            height: Dimensions.get('window').height
            }}>
            <Image 
                style={{ 
                    width: Dimensions.get('window').width, 
                    height: Dimensions.get('window').width, 
                    maxWidth: 300,
                    maxHeight: 300,
                    marginBottom: 40
                    }}
                source={image}/>
                <ActivityIndicator color="#FC6140" size={"large"} />
            <Text style={{ marginTop: 10 }}>Loading.. Please wait</Text>
        </View>
    )
};

export default LoadingScreen;