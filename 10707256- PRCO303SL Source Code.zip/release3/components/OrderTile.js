import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

const OrderTile = ({ order, navigation }) => {
    const OrderStatus =  ({ status }) => {
        switch(status) {
            case 'pending':
                return (
                    <Text style={[customStyles.status, { backgroundColor: '#DB8E1A'}]}>PENDING</Text>
                );
            case 'ongoing':
                return (
                    <Text  style={[customStyles.status, { backgroundColor: '#1F8781'}]}>IN PROGRESS</Text>
                );
            case 'completed':
                return (
                    <Text  style={[customStyles.status, { backgroundColor: '#327200'}]}>COMPLETED</Text>
                );
        }
    }
    return (
        <TouchableOpacity style={[ customStyles.tile ]} onPress={() => navigation.navigate("OrderView", { order, orderId: order.orderId })}>
            <Text style={{fontSize: 20, fontWeight: "bold"}}>
                {order.itemName}
            </Text>
            <Text>
                {order.orderId}
            </Text>
            <Text>
                {order.deliveryDate.toDate().toDateString()}
            </Text>
            <OrderStatus status={order.status} />
        </TouchableOpacity>

    );
};

const customStyles = StyleSheet.create({
    tile: {
        backgroundColor: "rgba(255, 255, 255, 0.6)",
        marginBottom: 20,
        padding: 20,
        elevation: 5,
        borderRadius: 5
    },
    status: {
        marginTop: 10,
        color: '#FFF',
        fontSize: 16,
        padding: 5,
        width: "40%",
        textAlign: 'center',
        borderRadius: 5
    }
})

export default OrderTile;