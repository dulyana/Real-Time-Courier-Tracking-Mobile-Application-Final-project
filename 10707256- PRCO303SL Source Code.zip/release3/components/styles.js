import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff",
    alignItems: "flex-start",
    justifyContent: "space-evenly",
    padding: 20,
    paddingTop: 40,
    height: "100%",
  },
  heading: {
    lineHeight: 30,
    fontSize: 30,
  },
  input: {
    width: '80%',
    color: '#000',
    borderColor: 'white',
    borderWidth: 0,
    borderBottomColor: "black",
    borderBottomWidth: 1
  },
  backgroundImage: {
    opacity: 0.1,
    resizeMode: "contain",
  },
  menu: {
    width: "100%",
    marginTop: 20,
  },
  menuItem: {
    backgroundColor: "#FC6140",
    paddingHorizontal: 20,
    paddingVertical: 20,
    width: "100%",
    marginVertical: 8,
    elevation: 5,
    borderRadius: 5,
    textAlign: 'left'
  },
  menuItemText: {
    color: "white",
    fontSize: 18,
  },
  orderTile: {
    backgroundColor: "#F4F4F4",
    opacity: 0.9,
    padding: 10,
    borderRadius: 5,
    elevation: 5,
    marginBottom: 10,
    marginHorizontal: 5
  },
  dashboardItem: {
    height: 140,
    width: 115,
    padding: 10,
    margin: 8,
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    elevation: 5
  },
  dashboardItemText: {
    textAlign: "center",
    color: "white",
    fontSize: 16,
  },
  dashboardItemCount: {
    textAlign: "center",
    color: "white",
    fontSize: 40,
    fontWeight: "bold",
  },
});

export default styles;