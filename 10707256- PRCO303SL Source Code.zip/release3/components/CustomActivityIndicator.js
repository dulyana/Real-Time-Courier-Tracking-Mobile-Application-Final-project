import React from "react";
import { ActivityIndicator } from "react-native";

const CustomActivityIndicator = () => {
    return (
        <ActivityIndicator color="#FC6140" size={"large"} />
    );
}

export default CustomActivityIndicator;