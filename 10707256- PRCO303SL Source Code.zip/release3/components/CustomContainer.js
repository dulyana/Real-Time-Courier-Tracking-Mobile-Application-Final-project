import React from "react";
import { Button, ImageBackground, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import styles from "./styles";
import loginImage from '../assets/images/loginImage.jpg';


const CustomContainer = (props) => {
  const { children, title } = props;

  return (
    <ImageBackground source={loginImage} style={{ flex: 1, justifyContent: 'center', alignContent:'center', height: '100%'}} imageStyle={ styles.backgroundImage}>
      <ScrollView contentContainerStyle={[ styles.container, { backgroundColor: 'transparent', justifyContent: 'flex-start'}]}>
        <Text style = {[ styles.heading, { marginBottom: 20, marginTop: 10 } ]}>{title}</Text>
        <View style={{ width: "100%" }}>
          {children}
        </View>
      </ScrollView>
    </ImageBackground>
  );
};


export default CustomContainer;