import React, { useEffect, useState } from "react";
import DropDownPicker from "react-native-dropdown-picker";

const CustomDropdown = (props) => {
    const { options, value, onChange, style, placeholder } = props;
    
    const [open, setOpen] = useState(false);
    const [selectedValue, setSelectedValue] = useState();
    const [items, setItems] = useState();

    useEffect(() => {
        setSelectedValue(value);
    }, [value]);

    useEffect(() => {
        setItems(options);
    }, [options]);

    const handleOnChange = (value) => {
        onChange(value);
        setSelectedValue(value);
    }

    return (
        <DropDownPicker
            open={open}
            setOpen={setOpen}
            items={items}
            value={selectedValue}
            setValue={handleOnChange}
            setItems={setItems}
            placeholder={placeholder || ""}
            TickIconComponent={null}
            hideSelectedItemIcon
            showTickIcon={false}
            style={[style, { width: '80%', zIndex: 100, backgroundColor: "rgba(255, 255, 255, 100"} ]}
            listMode="SCROLLVIEW"
        />
    );
};

export default CustomDropdown;