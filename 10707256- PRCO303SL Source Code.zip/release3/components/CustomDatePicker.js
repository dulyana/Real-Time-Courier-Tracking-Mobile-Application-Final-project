import { DateTimePickerAndroid } from "@react-native-community/datetimepicker";
import react from "react";
import { Button, View } from "react-native";

const CustomDatePicker = ({ date, onChange, style, disabled = false }) => {
    const showDatePicker = () => {
        DateTimePickerAndroid.open({
            value: date || new Date(),
            onChange: (e, val) => onChange(val),
            mode: 'date',
        })
    }

    return (
        <View style={[{ width: '80%'}, ...style]}>
            <Button 
            disabled={disabled}
            title={date ? date.toDateString(): 'Select date'} 
            onPress={showDatePicker}
            color="#7C7C7C"
            />
        </View>
    );
}

export default CustomDatePicker;