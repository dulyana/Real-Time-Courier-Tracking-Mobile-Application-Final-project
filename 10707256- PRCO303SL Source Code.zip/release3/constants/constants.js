export const USER_TYPE = {
    CUSTOMER: 'customer',
    COURIOR: 'courior',
    ADMIN: 'admin'
};

export const ORDER_STATUS = {
    PENDING: 'pending',
    ONGOING: 'ongoing',
    COMPLETED: 'completed'
};