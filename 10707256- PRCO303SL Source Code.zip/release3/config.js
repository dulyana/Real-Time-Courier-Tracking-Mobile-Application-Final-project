import { initializeApp } from 'firebase/app';
import { initializeAuth } from 'firebase/auth';
import { getReactNativePersistence } from 'firebase/auth/react-native';
import { initializeFirestore } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';


export const firebaseConfig = {
    apiKey: "AIzaSyA8oFa6jFk7doIw6dw3E-g8zQ5XaO3aaxc",
    authDomain: "tracking-app-7dbef.webapp.com",
    projectId: "tracking-app-7dbef",
    storageBucket: "tracking-app-7dbef.appspot.com",
    messagingSenderId: "865090997147",
    appId: "1:865090997147:web:a1082051b66ef835d5af3e"
}

const app = initializeApp(firebaseConfig);

export const firebaseAuth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage)
});
export const firestore = initializeFirestore(app, {
    experimentalForceLongPolling: true
});