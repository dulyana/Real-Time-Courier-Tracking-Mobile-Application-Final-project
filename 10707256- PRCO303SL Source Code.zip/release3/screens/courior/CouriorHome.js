import React, { useContext, useEffect, useState } from "react";
import { Text, View } from "react-native";
import UserContext from "../../components/UserContext";
import CustomButton from "../../components/CustomButton";
import CustomContainer from "../../components/CustomContainer";
import styles from "../../components/styles";
import { ORDER_STATUS } from "../../constants/constants";
import orderService from "../../services/orderService";
import userService from "../../services/userService";
import CustomDashboard from "../../components/CustomDashboard";

const CouriorHome = ({ navigation }) => {
    const user = useContext(UserContext);
    const [ ongoingOrder, setOngoingOrder ] = useState(null);

    useEffect(() => {
      const unsubscribe = navigation.addListener('focus', () => {
        if (navigation.isFocused() && user) {
          setOngoingOrder(false)
          orderService.getOrdersByCourior(user.uid, ORDER_STATUS.ONGOING)
          .then((orders) => orders.length && setOngoingOrder(orders[0]))
          .catch();
        }
      });
      return unsubscribe;
    }, [navigation, user]);


    return (
        <CustomContainer title="Dashboard">
          <CustomDashboard navigation={navigation} />
          <View style={[ styles.menu]} >
          { ongoingOrder &&
            <CustomButton
            style={[ styles.menuItem]} 
            title={"Current Order"} 
            onPress={() =>  navigation.navigate("OrderView", { orderId: ongoingOrder.orderId }) } />
          }
          <CustomButton
              style={[ styles.menuItem]} 
              title={"Pending Orders"} 
              onPress={() => {
                navigation.navigate("Orders", {status: "pending"});
              }}/>
          <CustomButton
              style={[ styles.menuItem]} 
              title={"Completed Orders"} 
              onPress={() => {
                navigation.navigate("Orders", {status: "completed"});
              }}/>
            <CustomButton
              style={[ styles.menuItem]} 
              title={"Log Out"} 
              onPress={() => {
                userService.logout();
              }}/>
          </View>
          
        </CustomContainer>
    );
}

export default CouriorHome;