import React, { useEffect, useState } from "react";
import { Dimensions, Image, ScrollView, Text, TextInput, TouchableOpacity, View  } from "react-native";
import styles from "../../components/styles";
import loginImage from '../../assets/images/loginImage.jpg';
import CustomButton from "../../components/CustomButton";
import CustomDropdown from "../../components/CustomDropdown";
import authService from "../../services/userService";
import SnackbarComponent from "expo-snackbar";

const Register = ({ navigation }) => {

  const [email, setEmail] = useState();
  const [name, setName] = useState();
  const [phoneNo, setPhoneNo] = useState();
  const [password, setPassword] = useState();
  const [category, setCategory] = useState();
  const [errorMessage, setErrorMessage] = useState(null);

  const onSubmit = async () => {
    if (email && password && category && name && phoneNo) {
      await authService.createUser({
        category,
        email,
        password,
        name,
        phoneNo
      }).catch((err) => {
        setErrorMessage(err.message);
      });
    } else {
      setErrorMessage('All fields are required')
    }
  }

  useEffect(()=> {
    if (errorMessage !== null) {
      setTimeout(() => {
        setErrorMessage(null);
      }, 2000);
    }
  }, [errorMessage]);

  return (
    
      <ScrollView 
        behavior="position"
      >
        <View style={[ styles.container]}>
          <Text style={[styles.heading, { marginTop: 30 }]}>Join Fast-Delivery{'\n'}Today!</Text>
          <Image 
            source={loginImage} 
            style={{ 
              width: Dimensions.get('window').width, 
              height: Dimensions.get('window').width, 
              maxWidth: 270,
              maxHeight: 270,
              marginTop: 20
            }} 
            />
          <Text style={{ fontSize: 20, marginBottom: 10}}>Please fill in to sign up</Text>
          <Text style={{ marginBottom: 0}}>Category</Text>
          <CustomDropdown 
            options={[
              {label: 'Customer', value: 'customer'},
              {label: 'Courior', value: 'courior'}
            ]}
            onChange={setCategory}
            value={category}
          />
           <Text style={{ marginTop: 15}}>Name</Text>
          <TextInput 
            textContentType="name" 
            style={ styles.input }
            placeholder="John Doe"
            onChangeText={ (text) => setName(text) }
            />
             <Text style={{ marginTop: 15}}>Phone No.</Text>
          <TextInput 
            textContentType="telephoneNumber" 
            style={ styles.input }
            placeholder="07x xxx xxxx"
            onChangeText={ (text) => setPhoneNo(text) }
            />
          <Text style={{ marginTop: 15}}>Email Address</Text>
          <TextInput 
            textContentType="emailAddress" 
            style={ styles.input }
            placeholder="john.doe@email.com"
            onChangeText={ (text) => setEmail(text) }
            />
          <Text style={{ marginTop: 15}}>Password</Text>
          <TextInput 
            textContentType="password" 
            secureTextEntry={true}
            style={[ styles.input, { marginBottom: 25 } ]} 
            placeholder="***********" 
            onChangeText={ (text) => setPassword(text)}
            />
          <CustomButton title="Sign Up" onPress={onSubmit}/>
          <View style={{ marginBottom: 5 }} />
          <TouchableOpacity onPress={() => navigation.navigate('Login')}>
            <Text>Have an account? <Text style={{ color: 'blue'}}>Login !</Text></Text>
          </TouchableOpacity>
          <View style={{ marginBottom:15 }}/>
          <SnackbarComponent visible={errorMessage !== null} textMessage={errorMessage} autoHidingTime={5000}/>
      </View>
    </ScrollView>
   
  );s
};

export default Register;