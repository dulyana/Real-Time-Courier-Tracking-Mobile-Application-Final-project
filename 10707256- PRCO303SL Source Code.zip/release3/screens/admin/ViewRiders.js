import React, { useEffect, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import CustomActivityIndicator from "../../components/CustomActivityIndicator";
import CustomContainer from "../../components/CustomContainer";
import userService from "../../services/userService";

const ViewRiders = () => {
  const [riders, setRiders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    userService.getUsers('courior')
      .then((data) => setRiders(data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <CustomContainer title="Riders">
      <ScrollView style={{ height: "90%" }}>
      {!loading && riders.map((rider) => (
        <View key={rider.uid} style={[ customStyles.riderTile ]}>
          <Text style={{ fontSize: 20 }}>{rider.name}</Text>
          <Text style={{ fontSize: 16 }}>{rider.email}</Text>
          <Text>{rider.phoneNo}</Text>
        </View>
      ))}
      {!loading && riders.length === 0 &&
        <Text style={{ textAlign: "center" }}>No riders yet!</Text>
      }
      {loading && <CustomActivityIndicator />}
      </ScrollView>
    </CustomContainer>
  );
};

const customStyles = StyleSheet.create({
  riderTile: {
    backgroundColor: "#F4F4F4",
    opacity: 0.9,
    padding: 10,
    borderRadius: 5,
    elevation: 5,
    marginBottom: 10,
    marginHorizontal: 5
  }
})

export default ViewRiders;
