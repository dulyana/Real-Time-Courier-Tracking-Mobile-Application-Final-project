import React, { useEffect, useState } from "react";
import { ActivityIndicator, Button, ImageBackground, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import styles from "../../components/styles";
import CustomContainer from "../../components/CustomContainer";
import CustomButton from "../../components/CustomButton";
import userService from "../../services/userService";
import orderService from "../../services/orderService";
import CustomDashboard from "../../components/CustomDashboard";

const defaultStats = {
  pending: 0,
  ongoing: 0,
  completed: 0
};

const AdminHome = ({ navigation }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState(defaultStats);

  useEffect(() => {
      const unsubscribe = navigation.addListener('focus', () => {
        if (navigation.isFocused()) {
          setIsLoading(true)
          orderService.getOrderStats()
            .then((orderStat) => setStats(orderStat))
            .catch().
            finally(() => setIsLoading(false));
        }
      });
      return unsubscribe;
  }, [navigation]);

  return (
    <CustomContainer title="Dashboard">
      <CustomDashboard navigation={navigation} />
      <View style={[ styles.menu, { marginTop: 80 }]}>
        
        <CustomButton 
          style={[ styles.menuItem]} 
          textStyle={[ styles.menuItemText]} 
          title={"Orders"} 
          onPress={() => {
            navigation.navigate("Orders");
          }}/>
                  <CustomButton 
          style={[ styles.menuItem]} 
          textStyle={[ styles.menuItemText]} 
          title={"Riders"} 
          onPress={() => {
            navigation.navigate("Riders");
          }}/>

        <CustomButton 
          style={[ styles.menuItem]} 
          textStyle={[ styles.menuItemText]} 
          title={"Customers"} 
          onPress={() => {
            navigation.navigate("Customers");
          }}/>

        <CustomButton 
          style={[ styles.menuItem]} 
          textStyle={[ styles.menuItemText]} 
          title={"Log Out"} 
          onPress={() => {
            userService.logout();
          }}/>
      </View>
    </CustomContainer>
  );
};

export default AdminHome;
