import React, { useEffect, useState } from "react";
import { PROVIDER_GOOGLE } from 'expo';
import { Image, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import styles from "../../components/styles.js";
import CustomContainer from "../../components/CustomContainer.js";
import MapView from "react-native-maps";
import CustomButton from "../../components/CustomButton.js";
import CustomDatePicker from "../../components/CustomDatePicker.js";
import marker from '../../assets/images/marker.png';
import userService from "../../services/userService.js";
import CustomDropdown from "../../components/CustomDropdown.js";
import orderService from "../../services/orderService.js";
import SnackbarComponent from "expo-snackbar";

const defaultDeliveryDestination = {
  latitude: 6.911096,
  longitude: 79.880456,
  latitudeDelta: 0.0922, 
  longitudeDelta: 0.0421 
};

const AddOrder = ({ navigation }) => {
  const [ allRiders, setAllRiders ] = useState([]);
  const [ allCustomers, setAllCustomers ] = useState([]);
  const [ itemName, setItemName ] = useState();
  const [ itemDescription, setItemDescription ] = useState();
  const [ rider, setRider ] = useState();
  const [ receiver, setReceiver ] = useState();
  const [ deliveryDate, setDeliveryDate ] = useState();
  const [ address, setAddress ] = useState();
  const [ deliveryDestination, setDeliveryDestination ] = useState(defaultDeliveryDestination);
  const [paymentMethod, setPaymentMethod] = useState();
  const [ errorMessage, setErrorMessage ] = useState(null);

  useEffect(() => {
    userService.getUsers('courior')
      .then((data) => setAllRiders(data))
      .catch();

    userService.getUsers('customer')
      .then((data) => setAllCustomers(data))
      .catch();
  }, []);


  useEffect(()=> {
    if (errorMessage !== null) {
      setTimeout(() => {
        setErrorMessage(null);
      }, 2000);
    }
  }, [errorMessage]);


  const onSubmit = () => {
    if (itemName && itemDescription && rider && receiver && deliveryDate && address && deliveryDestination && paymentMethod) {
      orderService.addOrder({
        itemName,
        itemDescription,
        rider,
        receiver,
        deliveryDate,
        deliveryDestination,
        address,
        paymentMethod
      }).then(() => {
        setErrorMessage('Order was added successfully');
        navigation.goBack();
      }).catch((err) => {
        setErrorMessage(err.message);
      })
    }else {
      setErrorMessage('All fields are required!');
    }
  };

  return (
    <CustomContainer title="Add Order">
      <ScrollView style={{height: '90%'}}>
       <Text style={{ marginTop: 10}}>Item Name</Text>
        <TextInput 
          style={ styles.input }
          onChangeText={ (text) => setItemName(text) }
          />
        <Text style={{ marginTop: 15}}>Item Description</Text>
        <TextInput 
          style={ styles.input }
          onChangeText={ (text) => setItemDescription(text) }
          />
        <Text style={{ marginTop: 15, marginBottom: 5}}>Rider</Text>
        <CustomDropdown 
          value = {rider}
          onChange = {setRider}
          placeholder = "Select Rider"
          options={allRiders.map(({ name, uid }) => ({
            label: name, value: uid
          }))}
        />
        <Text style={{ marginTop: 15}}>Receiver</Text>
        <CustomDropdown 
          value = {receiver}
          onChange = {setReceiver}
          placeholder = "Select Receiver"
          options={allCustomers.map(({ name, uid }) => ({
            label: name, value: uid
          }))}
        />
        <Text style={{ marginTop: 15}}>Payment Method</Text>
        <CustomDropdown 
          value = {paymentMethod}
          onChange = {setPaymentMethod}
          placeholder = "Select Payment Method"
          options={[
            { label: 'Cash on Delivery', value: 'Cash on Delivery'},
            { label: 'Internet Payment', value: 'Internet Payment'}
          ]}
        />
        <Text style={{ marginTop: 15}}>Delivery Date</Text>
        <CustomDatePicker 
          date={deliveryDate} 
          onChange={setDeliveryDate} 
          style={[{ marginTop: 5 }]}
          />
        <Text style={{ marginTop: 15}}>Address</Text>
        <TextInput 
          style={ styles.input }
          onChangeText={ (text) => setAddress(text) }
          />
        <Text style={{ marginTop: 25}}>Delivery Destination</Text>
        <View style={customStyles.map}>
        <MapView
            provider={PROVIDER_GOOGLE}
            style={[{ height: '100%', width: '100%'}]}
            initialRegion={deliveryDestination} 
            onRegionChangeComplete={setDeliveryDestination}
          >
            </MapView>
            <View style={customStyles.markerFixed}>
              <Image style={customStyles.marker} source={marker} />
            </View>
        </View>
          
          <CustomButton title="Add Order" onPress={onSubmit} style={{marginTop: 30}}/>
          <SnackbarComponent visible={errorMessage !== null} textMessage={errorMessage} autoHidingTime={2000}/>
      </ScrollView>
    </CustomContainer>
  );
};

export default AddOrder;

const customStyles = StyleSheet.create({
  map: {
    marginTop: 10,
    marginBottom: 20,
    height: 300,
    width: '100%'
  },
  markerFixed: {
    left: '50%',
    marginLeft: -30,
    marginTop: -60,
    position: 'absolute',
    top: '50%'
  },
  marker: {
    height: 60,
    width: 60,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2
  },
  footer: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    bottom: 0,
    position: 'absolute',
    width: '100%'
  },
  region: {
    color: '#fff',
    lineHeight: 20,
    margin: 20
  }
})