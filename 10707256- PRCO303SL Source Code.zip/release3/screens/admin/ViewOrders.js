import React, { useEffect, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { FloatingAction } from "react-native-floating-action";
import CustomActivityIndicator from "../../components/CustomActivityIndicator";
import CustomContainer from "../../components/CustomContainer";
import OrderTile from "../../components/OrderTile";
import orderService from "../../services/orderService";

const ViewOrders = ({ navigation }) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      if (navigation.isFocused()) {
        setLoading(true);
        orderService.getOrders()
        .then((data) => setOrders(data))
        .catch((err) => setError(err.message))
        .finally(() => setLoading(false));
      }
    });
    return unsubscribe;
  }, [navigation]);

  return (
      <CustomContainer title="Orders">
      <ScrollView style={{ height: "90%" }}>
      {!loading && orders.map((order) => (<OrderTile key={order.orderId} order={order} navigation={navigation}/>))}
      {!loading && orders.length === 0 &&
        <Text style={{ textAlign: "center" }}>No orders yet!</Text>
      }
      {loading && <CustomActivityIndicator />}
      </ScrollView>
      <FloatingAction 
        actionsPaddingTopBottom={0} 
        showBackground={false}
        color="#FC6140"
        onPressMain={() => navigation.navigate("AddOrder")}
        />
    </CustomContainer>
  );
};

const customStyles = StyleSheet.create({
  orderTile: {
    backgroundColor: "#F4F4F4",
    opacity: 0.9,
    padding: 10,
    borderRadius: 5,
    elevation: 5,
    marginBottom: 10,
    marginHorizontal: 5
  }
})
export default ViewOrders;