import React, { useContext, useEffect, useState } from "react";
import { ActivityIndicator, Text, View } from "react-native";
import CustomButton from "../../components/CustomButton";
import CustomContainer from "../../components/CustomContainer";
import userService from "../../services/userService";
import styles from "../../components/styles";
import { ORDER_STATUS } from "../../constants/constants";
import UserContext from "../../components/UserContext";
import orderService from "../../services/orderService";
import CustomDashboard from "../../components/CustomDashboard";

const CustomerHome = ({ navigation }) => {
    const user = useContext(UserContext);
    const [loading, setLoading] = useState(true);

    const handleOnLogout = async () => {
        await userService.logout();
    }

    return (
        <CustomContainer title="Dashboard">
          <CustomDashboard navigation={navigation} />
          <View style={[ styles.menu]} >
          <CustomButton
              style={[ styles.menuItem]} 
              title={"Ongoing Orders"} 
              onPress={() => {
                navigation.navigate("Orders", {status: ORDER_STATUS.ONGOING});
              }}/>
          <CustomButton
              style={[ styles.menuItem]} 
              title={"Pending Orders"} 
              onPress={() => {
                navigation.navigate("Orders", {status: ORDER_STATUS.PENDING});
              }}/>
          <CustomButton
              style={[ styles.menuItem]} 
              title={"Completed Orders"} 
              onPress={() => {
                navigation.navigate("Orders", {status: ORDER_STATUS.COMPLETED});
              }}/>
            <CustomButton
              style={[ styles.menuItem]} 
              title={"Log Out"} 
              onPress={() => handleOnLogout()}/>
          </View>
          
        </CustomContainer>

    );
}

export default CustomerHome;