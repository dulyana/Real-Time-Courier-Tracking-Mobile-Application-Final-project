import React, { useContext, useEffect, useState } from "react";
import { ScrollView, Text, View } from "react-native";
import UserContext from "../../components/UserContext";
import CustomContainer from "../../components/CustomContainer";
import orderService from "../../services/orderService";
import styles from "../../components/styles";
import OrderTile from "../../components/OrderTile";
import { ORDER_STATUS } from "../../constants/constants";
import CustomActivityIndicator from "../../components/CustomActivityIndicator";

const ViewOrders = ({ route, navigation }) => {
    const user = useContext(UserContext);
    const [status, setStatus] = useState(null);
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setStatus(route.params.status)
    }, [route]);

    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', () => {
            const currentStatus = route.params.status;
          if (navigation.isFocused() && currentStatus) {
            setLoading(true);
            orderService.getOrdersByCustomer(user.uid, currentStatus)
                .then((data) => setOrders(data))
                .catch()
                .finally(() => setLoading(false));
          }
        });
        return unsubscribe;
      }, [navigation]);

    const getViewTitle = () => {
        switch(status) {
            case ORDER_STATUS.ONGOING:
                return 'Ongoing Orders';
            
            case ORDER_STATUS.PENDING:
                return 'Pending Orders';
            
            case ORDER_STATUS.COMPLETED:
                return 'Completed Orders';
        }

        return 'Orders';
    }
    return (
        <CustomContainer title={getViewTitle()}>
            <ScrollView style={{height: "90%"}}>
            {!loading && orders.map((order) => (<OrderTile key={order.orderId} order={order} navigation={navigation} />))}
                {!loading && orders.length === 0 &&
                    <Text style={{ textAlign: "center" }}>No orders yet!</Text>
                }
                { loading && <CustomActivityIndicator />}
            </ScrollView>
        </CustomContainer>
    );
};

export default ViewOrders;