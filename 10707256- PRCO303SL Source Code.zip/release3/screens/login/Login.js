import SnackbarComponent from "expo-snackbar";
import React, { useEffect, useState } from "react";
import { Dimensions, Image, ScrollView, Text, TextInput, TouchableOpacity, View  } from "react-native";
import loginImage from '../../assets/images/loginImage.jpg';
import CustomButton from "../../components/CustomButton";
import styles from "../../components/styles";
import userService from "../../services/userService";

const Login = ({ navigation }) => {
  const [ email, setEmail ] = useState(null);
  const [ password, setPassword ] = useState(null);
  const [ errorMessage, setErrorMessage ] = useState(null);

  const onSubmit = async (e) => {
    e.preventDefault();
    if (email && password) {
      await userService.login({ email, password })
        .catch((err) => {
          setErrorMessage("Login failed. Please try again!");
        });
    } else {
      setErrorMessage("All fields are required");
    }
  }

  useEffect(()=> {
    if (errorMessage !== null) {
      setTimeout(() => {
        setErrorMessage(null);
      }, 2000);
    }
  }, [errorMessage]);

  return (
    <ScrollView>
      <View style={ styles.container }>
      <Text style={[styles.heading, { marginTop: 30 }]}>Welcome{'\n'}back!</Text>
      <Image 
        source={loginImage} 
        style={{ 
          width: Dimensions.get('window').width, 
          height: Dimensions.get('window').width, 
          maxWidth: 360,
          maxHeight: 360,
          marginTop: 'auto' 
        }} 
        />
      <Text style={{ fontSize: 20, marginBottom: 10}}>Please sign in to continue</Text>
      <Text>Email Address</Text>
      <TextInput 
        textContentType="emailAddress" 
        style={ styles.input }
        placeholder="john.doe@email.com"
        onChangeText={ (text) => setEmail(text) }
        />
      <Text style={{ marginTop: 10}}>Password</Text>
      <TextInput 
        textContentType="password" 
        secureTextEntry={true}
        style={[ styles.input, { marginBottom: 20 } ]} 
        placeholder="***********" 
        onChangeText={ (text) => setPassword(text) }
        />
      <CustomButton title="Sign In" onPress={onSubmit}/>
      <View style={{ marginBottom: 20 }}/>
      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text>Don't have an account? <Text style={{ color: 'blue'}}>Register today !</Text></Text>
      </TouchableOpacity>
      <View style={{ marginBottom: 15 }}/>
      <SnackbarComponent visible={errorMessage !== null} textMessage={errorMessage} autoHidingTime={5000}/>
    </View>
    </ScrollView>
  );
};

export default Login;