import { useEffect, useState } from 'react';
import {getAuth, onAuthStateChanged} from 'firebase/auth';
import { StyleSheet, Text, View, LogBox } from 'react-native';
import { firebaseConfig } from './config.js';
import PublicApp from './Apps/Public/PublicApp.js';
import PrivateApp from './Apps/Private/PrivateApp.js';
import {decode, encode} from 'base-64';
import LoadingScreen from './components/LoadingScreen.js';

if (!global.btoa) {  global.btoa = encode }

if (!global.atob) { global.atob = decode } 

LogBox.ignoreAllLogs();
export default function App() {
  const [initializing, setInitializing] = useState(true);
  const [user, setUser] = useState();
  
  useEffect(() => {
    const auth = getAuth();

    return onAuthStateChanged(auth, user => {
      setUser(user);
      if (initializing) {
        setInitializing(false);
      }
    });
  }, []);

  if (initializing) {
    return (
      <LoadingScreen />
    );
  }

  if (user) {
    return (
      <PrivateApp user={user} />
    );
  }

  return (
     <PublicApp />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
